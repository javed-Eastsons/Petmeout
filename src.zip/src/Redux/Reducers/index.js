import {combineReducers} from 'redux';
import PetmeOutReducer from './PetmeOutReducer';


export default combineReducers({
  PetmeOutReducer,
  
});
