import {
  LOGIN_DATA,
  PET_LIST,
  COUNTRY_LIST,
  STATE_LIST,
  CITY_LIST,
  CATEGORY_LIST,
  BREED_LIST,
  ALL_POSTS,
  ALLPETS_CATEGORY,
  USER_DATA
} from './types';
import AsyncStorage from '@react-native-community/async-storage';
import axios, * as others from 'axios';
import { Alert } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { logistical } from '../../utils';
import { Globals } from '../../Config/index';


export const LoginUser = (email, pass, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/UserLogin/UserLogin.php";
    var formData = new FormData();
    formData.append('email', email);
    formData.append('password', pass);

    console.log("FORMDATAAAAA", formData);

    return fetch(url1, {
      method: "POST",
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),

      body: formData,
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {
          AsyncStorage.setItem('token', JSON.stringify(responseJson.token));
          console.log(responseJson.accessToken, 'token');


          dispatch({
            type: LOGIN_DATA,
            payload: responseJson,
          });
          dispatch(userDetails(responseJson?.user_id));
          navigation.navigate('Auth')
          //   Alert.alert(response.response[0])
          resolve(responseJson);
        } else {
          Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const registerUser = (username, email, pass, gender,address, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/UserRegistration/UserRegistration.php";
    var formData = new FormData();
    formData.append('username', username);
    formData.append('email', email);
    formData.append('password', pass);
    formData.append('gender', gender);
    formData.append('address', address);
    formData.append('device_token', 'erhge534y859748jejhejr893758jerrtretret');
    formData.append('device_type', 'Android');


    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: ` ${Globals.baseUrl}/UserRegistration/UserRegistration.php`,
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),
      data: formData
    };

    axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data), 'hhh');
        Alert.alert(JSON.stringify(response.data?.message))
        navigation.navigate('Login');
      })
      .catch((error) => {
        console.log(error);
      });
    // .catch ((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const petListing = (email, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      `/PetListing/RegisteredUserPetListing.php?email=${email}`;



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'HIMHIMHIMHIMHIMHIM');


          dispatch({
            type: PET_LIST,
            payload: responseJson?.Pet_List,
          });

          resolve(responseJson);
        } else {
          Alert.alert(responseJson?.message);
          dispatch({
            type: PET_LIST,
            payload: null,
          });
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const countryList = () => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/CountryList/CountryList.php";



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'countrycountrycountry');


          dispatch({
            type: COUNTRY_LIST,
            payload: responseJson?.country_list,
          });

          resolve(responseJson);
        } else {
          Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const stateList = (countryId) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      `/StateList/StateList.php?country_id=${countryId}`;



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'statestatestatestate');


          dispatch({
            type: STATE_LIST,
            payload: responseJson?.state_list,
          });

          resolve(responseJson);
        } else {
          // Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const cityList = (stateId) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      `/CityList/CityList.php?state_id=${stateId}`;



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'citycitycitycitycitycitycity');


          dispatch({
            type: CITY_LIST,
            payload: responseJson?.city_list,
          });

          resolve(responseJson);
        } else {
          // Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};


export const categoryList = () => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/CategoryList/CategoryList.php";



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("CategoryList", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'CategoryListCategoryListCategoryList');


          dispatch({
            type: CATEGORY_LIST,
            payload: responseJson?.Category_List,
          });

          resolve(responseJson);
        } else {
          console.log('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const breedList = (catId) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      `/BreedList/BreedList.php?pet_category_id=${catId}`;


    console.log(url1, 'url1111')
    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'BREED_LISTBREED_LISTBREED_LIST');


          dispatch({
            type: BREED_LIST,
            payload: responseJson?.Breed_list,
          });

          resolve(responseJson);
        } else {
          // Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const allPetsPostListing = (email, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/AllPetsPostListing/AllPetsPostListing.php";
    var formData = new FormData();
    formData.append('user_login_email', email);

    console.log("allPetsPostListingFORMDATAAAAA", formData);

    return fetch(url1, {
      method: "POST",
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),

      body: formData,
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("ALL_POSTSALL_POSTSALL_POSTS", responseJson);

        if (responseJson.status == true) {


          dispatch({
            type: ALL_POSTS,
            payload: responseJson?.Post_List,
          });
          resolve(responseJson);
        } else {
          // Alert.alert('Something Went Wrong');
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};


export const AllPetsListingByCategory = cat_name => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      `/AllPetsListingByCategory/AllPetsListingByCategory.php?cat_name=${cat_name}`;



    return fetch(url1, {
      method: "GET",
      headers: {}
    })
      .then((response) => response.json())
      .then(async (responseJson) => {
        console.log("AllPetsListingByCategory", responseJson);

        if (responseJson.status == true) {

          console.log(responseJson, 'AllPetsListingByCategoryAllPetsListingByCategory');


          dispatch({
            type: ALLPETS_CATEGORY,
            payload: responseJson?.all_Pets,
          });

          resolve(responseJson);
        } else {
          // Alert.alert('Something Went Wrong');
          dispatch({
            type: ALLPETS_CATEGORY,
            payload: null,
          })
        }
      })
      .catch((error) => console.log("LLLLLLLLL", error.message));
  };
};


export const logout = (email, navigation) => {
  return (dispatch, getState) => {


    AsyncStorage.setItem('token', null);


    dispatch({
      type: LOGIN_DATA,
      payload: null,
    });
    navigation.navigate('Login');

  };
};

export const registerPet = (petName, gender, categoryName, breedName, age, color, weight, unit, countryName, stateName, cityName, desc, image, email,pincode, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +

      "PetRegistration/PetRegistration.php";
    let data = new FormData();
    data.append('petname', petName);
    data.append('gender', gender);
    data.append('category', categoryName);
    data.append('bread', breedName);
    data.append('age', age);
    data.append('color', color);
    data.append('weight', weight);
    data.append('unit', unit);
    data.append('Country', countryName);
    data.append('State', stateName);
    data.append('City', cityName);
    data.append('pincode', pincode);
    data.append('desc', desc);
    data.append('pet_image', image);
    data.append('email', email);

    console.log(data, 'formDattttaaa')
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'https://refuel.site/projects/socialzoo/API/PetRegistration/PetRegistration.php',
      headers: {
        // ...data.getHeaders()
      },
      data: data
    };
    return axios.request(config)
      .then((response) => {
        console.log(response,'responseresponseresponse')
        if (response.data.status == true) {
          Alert.alert(response.data.message)
          dispatch(petListing(email, navigation));
          navigation.goBack()

        } else {
          console.log('error')
        }
      })
      .catch((error) => {
        console.log(error);
      })

  };
};


export const deleteRegisterPet = (petId, email, navigation) => {
  return (dispatch, getState) => {
    let data = new FormData();
    data.append('pet_id', petId);
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'https://refuel.site/projects/socialzoo/API/DeletePet/DeletePet.php',
      headers: {
        // ...data.getHeaders()
      },
      data: data
    };

    axios.request(config)
      .then((response) => {
        console.log(response.data, 'ddddddddd');
        if (response.data.status == true) {
          Alert.alert(response.data.message)
          dispatch(petListing(email, navigation));

        }
      })
      .catch((error) => {
        console.log(error);
      });

  };
};
export const deleteCategory = (catId, navigation) => {
  return (dispatch, getState) => {
    let data = new FormData();
    data.append('category_id', catId);
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'https://refuel.site/projects/socialzoo/API/DeletePetCategory/DeletePetCategory.php',
      headers: {
        // ...data.getHeaders()
      },
      data: data
    };
console.log(data,'foooooo')
    axios.request(config)
      .then((response) => {
        console.log(response.data, 'ddddddddd');
        if (response.data.status == true) {
          Alert.alert(response.data.message)
          dispatch(categoryList());
          // dispatch(petListing(email, navigation));

        }
      })
      .catch((error) => {
        console.log(error);
      });

  };
};
export const userDetails = (id) => {
  return (dispatch, getState) => {
    let data = new FormData();
    data.append('user_id', id);
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'https://refuel.site/projects/socialzoo/API/UserList/UserList.php',
      headers: {
        // ...data.getHeaders()
      },
      data: data
    };
console.log(data,'formdataprofile')
    axios.request(config)
      .then((response) => {
        console.log(response.data, 'profileUser');
        if (response.data.status == true) {
          dispatch({
            type: USER_DATA,
            payload: response?.data?.UserList,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });

  };
};

export const addCategory = (name, image, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/PetCategory/PetCategory.php";
    var formData = new FormData();
    formData.append('cat_name', name);
    formData.append('cat_image', image);
    


    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: ` ${Globals.baseUrl}/PetCategory/PetCategory.php`,
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),
      data: formData
    };

    axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data), 'hhh');
        Alert.alert(JSON.stringify(response.data?.message))
        dispatch(categoryList());
      })
      .catch((error) => {
        console.log(error);
      });
    // .catch ((error) => console.log("LLLLLLLLL", error.message));
  };
};

export const editCategory = (id ,name, image, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "/EditCategory/EditCategory.php";
    var formData = new FormData();
    formData.append('category_id', id);
    formData.append('cat_name', name);
    formData.append('cat_image', image);
    


    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: ` ${Globals.baseUrl}/EditCategory/EditCategory.php`,
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),
      data: formData
    };

    axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data), 'hhh');
        Alert.alert(JSON.stringify(response.data?.message))
        dispatch(categoryList());
      })
      .catch((error) => {
        console.log(error);
      });
    // .catch ((error) => console.log("LLLLLLLLL", error.message));
  };
};


export const updateUserProfile = (id ,name,email,gender, image, navigation) => {
  return (dispatch, getState) => {
    const url1 =
      Globals.baseUrl +
      "UpdateUserProfile/UpdateUserProfile.php";
    var data = new FormData();
    data.append('user_id', id);
    data.append('username', name);
    data.append('email', email);
    data.append('gender', gender);
    data.append('userimg', image);
    


    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: ` ${Globals.baseUrl}/UpdateUserProfile/UpdateUserProfile.php`,
      headers: new Headers({
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
        // "Authorization": authtoken,
      }),
      data: data
    };

    axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data), 'hhh');
        Alert.alert(JSON.stringify(response.data?.message))
        dispatch(userDetails(id));
      })
      .catch((error) => {
        console.log(error);
      });
    // .catch ((error) => console.log("LLLLLLLLL", error.message));
  };
};




