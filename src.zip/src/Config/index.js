export const Globals = {
  // baseUrl: 'https://refuel.site/projects/petme/API',
  // baseUrl:'https://socialzoo.org/API',
  baseUrl:'https://refuel.site/projects/socialzoo/API',
  categoriesImagePath :'https://refuel.site/projects/socialzoo/admin/upload/'
};
