export const Globals = {
  baseUrl: 'https://restapi.taxleaf.com',
  // baseUrl: 'https://stagingclientportal.taxleaf.com',
};
