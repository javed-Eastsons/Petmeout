export const Color = {
  geen: '#82be4e',
  

  backgroundcolor: '',
  // geen: '#9db436',
  green:'#82be4e',
  darkGreen: '#2F4050',
  white: '#fff',
  bgColor:'#d0e4e6',
  headerIconBG:'#00818a'
};
