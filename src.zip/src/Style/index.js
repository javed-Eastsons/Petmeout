export const Color = {
  backgroundcolor: '',
  geen: '#9db436',
  darkGreen: '#2F4050',
  white: '#fff',
};
