import { StyleSheet, Text, View,ScrollView } from 'react-native'
import React from 'react'

const About = () => {
    return (
        <View>
            <ScrollView>
            <View >
                <View
                    style={{
                        height: 40,

                        width: '100%',
                        paddingLeft: 10,
                        alignSelf: 'center',
                        justifyContent: 'center',
                        marginTop:20
                        //   backgroundColor: 'green',
                    }}>
                    <Text style={styles.head}>
                        Contact Information
                    </Text>
                </View>
                <View style={styles.partition}></View>

                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Email:</Text>{' '}
                        Walter@gmail.com
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Mobile:</Text>{' '}
                        (001) 4544 565 456
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Address:</Text>{' '}
                        United States of America
                    </Text>
                </View>
            </View>
            <View >
                <View
                    style={{
                        height: 40,

                        width: '100%',
                        paddingLeft: 10,
                        alignSelf: 'center',
                        justifyContent: 'center',
                        marginTop:20
                        //   backgroundColor: 'green',
                    }}>
                    <Text style={styles.head}>
                        Websites and Social Links
                    </Text>
                </View>
                <View style={styles.partition}></View>

                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Website:</Text>{' '}
                        www.petmeout.com
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Social Link:</Text>{' '}
                        www.petmeout.com
                    </Text>
                </View>

            </View>
            <View >
                <View
                    style={{
                        height: 40,

                        width: '100%',
                        paddingLeft: 10,
                        alignSelf: 'center',
                        justifyContent: 'center',
                        marginTop:20
                        //   backgroundColor: 'green',
                    }}>
                    <Text style={styles.head}>
                        Basic Information
                    </Text>
                </View>
                <View style={styles.partition}></View>

                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Birth Date:</Text>{' '}
                        24 January
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Birth Year:</Text>{' '}
                        1994
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>Gender:</Text>{' '}
                        Male
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>interested in:</Text>{' '}
                        Designing
                    </Text>
                </View>
                <View
                    style={{
                        height: 40,
                        //   backgroundColor: '#fff',

                        padding: 10,
                    }}>
                    <Text style={styles.LIstText}>
                        <Text style={styles.keyText}>language:</Text>{' '}
                        English, French
                    </Text>
                </View>
            </View>
            </ScrollView>
        </View>
    )
}

export default About

const styles = StyleSheet.create({
    content: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    LIstText2: {
        fontSize: 14,
        fontFamily: 'Poppins-Regular',
        color: 'black',
    },
    LIstText: {
        fontSize: 12,
        fontFamily: 'Poppins-Regular',
        color: 'gray',
    },
    partition: {
        borderWidth: 0.5,
        borderColor: '#A7B1C2',

    },
    keyText:{ fontSize: 14, fontFamily: 'Poppins-Regular' ,color:'#000'},
    head:{ fontSize: 17, fontFamily: 'Poppins-SemiBold', color: '#000', textAlign: 'left' }
})