import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionic from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import { useSelector, useDispatch } from 'react-redux';
import { allPetsPostListing } from '../Redux/Actions/Petmeout';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { Loader } from '../Component/Loader';

const ProfilePosts = () => {
  const { LOGIN_DATA } = useSelector(state => state.PetmeOutReducer);
  const { ALL_POSTS } = useSelector(state => state.PetmeOutReducer);

  const dispatch = useDispatch();
  const [loader, setLoader] = useState(false);
  const navigation = useNavigation();

  console.log(ALL_POSTS, 'PPPPPPPPPPPPPP')
  const email = LOGIN_DATA?.email;
  useEffect(() => {
    setLoader(true);
    dispatch(allPetsPostListing(email, navigation));
    setTimeout(() => {
      setLoader(false);
    }, 2000);
  }, []);
  const postInfo = [
    {
      postTitle: 'Dog',
      postPersonImage: require('../Assets/cat2.jpg'),
      postImage: require('../Assets/cat.jpg'),
      likes: 765,
      isLiked: false,
    },
    {
      postTitle: 'Cat',
      postPersonImage: require('../Assets/cat3.jpg'),
      postImage: require('../Assets/cat1.jpg'),
      likes: 345,
      isLiked: false,
    },
    {
      postTitle: 'Catty',
      postPersonImage: require('../Assets/cat2.jpg'),
      postImage: require('../Assets/cats.jpg'),
      likes: 734,
      isLiked: false,
    },
    {
      postTitle: 'The_Groot',
      postPersonImage: require('../Assets/profile3.jpg'),
      postImage: require('../Assets/profile3.jpg'),
      likes: 875,
      isLiked: false,
    },
  ];

  return (
    <View>
      <Loader flag={loader} />
      <ScrollView>
        {ALL_POSTS?.map((data, index) => {
          // const [like, setLike] = useState(data.isLiked);
          return (
            <View
              key={index}
              style={{
                paddingBottom: 10,
                borderBottomColor: 'gray',
                borderBottomWidth: 0.1,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: 15,
                }}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Image
                    source={{ uri:data.pet_image}}
                    style={{ width: 40, height: 40, borderRadius: 100 }}
                  />
                  <View style={{ paddingLeft: 5 }}>
                    <Text style={{ fontSize: 15, fontWeight: 'bold',color:'#000' }}>
                      {data.pet_name}
                    </Text>
                  </View>
                </View>
                <Feather name="more-vertical" style={{ fontSize: 20 }} color="#000" />
              </View>
              <View
                style={{
                  position: 'relative',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  source={data.post_img}
                  style={{ width: '100%', height: 400 }}
                />
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingHorizontal: 12,
                  paddingVertical: 15,
                }}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <TouchableOpacity 
                  // onPress={() => setLike(!like)}
                  >
                    <AntDesign
                      // name={like ? 'heart' : 'hearto'}
                      name='hearto'
                      style={{
                        paddingRight: 10,
                        fontSize: 20,
                        color: 'black',
                      }}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Ionic
                      name="chatbubble-outline"
                      color="#000"
                      style={{ fontSize: 20, paddingRight: 10 }}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Feather name="navigation" style={{ fontSize: 20 }} color="#000"s />
                  </TouchableOpacity>
                </View>
                <Feather name="bookmark" style={{ fontSize: 20 }} />
              </View>
              <View style={{ paddingHorizontal: 15 }}>
                <Text style={{color:'#000'}}>
                  {/* Liked by {like ? 'you and' : ''}{' '} */}
                  { data.likes} others
                </Text>
                {/* <Text
                style={{
                  fontWeight: '700',
                  fontSize: 14,
                  paddingVertical: 2,
                }}>
                If enjoy the video ! Please like and Subscribe :)
              </Text> */}
                <Text style={{ opacity: 0.4, paddingVertical: 2,color:'#000' }}>
                  View all comments
                </Text>
                <View
                  style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Image
                     source={{ uri:data.pet_image}}
                      style={{
                        width: 25,
                        height: 25,
                        borderRadius: 100,
                        backgroundColor: 'orange',
                        marginRight: 10,
                      }}
                    />
                    <TextInput
                      placeholder="Add a comment "
                      placeholderTextColor={'#000'}
                      style={{ opacity: 0.5}}
                    />
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Entypo
                      name="emoji-happy"
                      style={{ fontSize: 15, color: 'lightgreen', marginRight: 10 }}
                    />
                    <Entypo
                      name="emoji-neutral"
                      style={{ fontSize: 15, color: 'pink', marginRight: 10 }}
                    />
                    <Entypo
                      name="emoji-sad"
                      style={{ fontSize: 15, color: 'red' }}
                    />
                  </View>
                </View>
              </View>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default ProfilePosts;