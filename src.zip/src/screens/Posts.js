import { StyleSheet, Text, View, Image, TextInput, ScrollView, FlatList,TouchableOpacity } from 'react-native'
import React, { useState, useEffect, useCallback } from 'react'
import Icon from 'react-native-vector-icons/Entypo';
import Icon1 from 'react-native-vector-icons/AntDesign';
import { Color } from '../Style';
import { useDispatch, useSelector } from 'react-redux';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { Loader } from '../Component/Loader';
import { allPetsPostListing } from '../Redux/Actions/Petmeout';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Modal from "react-native-modal";
import DocumentPicker from 'react-native-document-picker'
import { launchImageLibrary } from 'react-native-image-picker';

const Posts = ({ route }) => {
    console.log(route.params, 'routeeee')
    const petDetails = route?.params?.petDetails
    const [showPostModal, setShowPostModal] = useState(false)
    const [base64File, setBase64File] = useState();
    const [base64Image, setBase64Image] = useState()
    const [imageUri, setImageUri] = useState();
    const { LOGIN_DATA } = useSelector(state => state.PetmeOutReducer);
    const { ALL_POSTS } = useSelector(state => state.PetmeOutReducer);
    const [allPosts, setAllPosts] = useState([])
    const dispatch = useDispatch();
    const navigation = useNavigation();
    const [postContent, setPostContent] = useState()
    const [base64String, setBase64String] = useState(null);


    console.log(ALL_POSTS, 'ALL_POSTS_POPOPOP')

    const [loader, setLoader] = useState(false);
    const openModal = (id) => {
        setShowPostModal(true)
    }
    const likePost = (id) => {
        console.log('Liking post with ID:', id);
        setAllPosts((prevItems) => {
            const updatedItems = prevItems.map((item) =>
                item.id === id ? { ...item, likes: item.likes + 1 } : item
            );
            console.log('Updated Items:', updatedItems); // Logging the updated state
            return updatedItems;
        });
    };

    const pickImageFromGallery = () => {
        let options = {
            mediaType: 'photo',
            quality: 1,
        };
        launchImageLibrary(options, (response) => {
            if (response.didCancel) {
                console.log('User cancelled image picker');
            } else if (response.errorCode) {
                console.log('ImagePicker Error: ', response.errorMessage);
            } else {
                const uri = response.assets[0].uri;
                setImageUri(uri);
                convertToBase64(uri)
            }
        });
    };
    const convertToBase64 = async (uri) => {
        try {
            const response = await fetch(uri);
            const blob = await response.blob();
            const reader = new FileReader();
            reader.onloadend = () => {
                setBase64String(reader.result.split(',')[1]);
            };
            reader.readAsDataURL(blob);
        } catch (error) {
            console.log('Error converting image to base64:', error);
        }
    };

    useEffect(() => {
        setLoader(true);
        dispatch(allPetsPostListing(LOGIN_DATA?.email, navigation));
        setTimeout(() => {
            setLoader(false);
        }, 2000);
    }, []);

    useEffect(() => {
        setAllPosts(ALL_POSTS);
    }, [ALL_POSTS]);
    return (
        <View>
            <Loader flag={loader} />
            <ScrollView>
                <View style={{ backgroundColor: '#fff', padding: 10, width: '95%', alignSelf: 'center', marginTop: 10 }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text style={{ fontSize: 17, color: 'gray' }}>Create Post</Text>
                        <Icon name='dots-three-horizontal' size={20} color="gray" />
                    </View>
                    <View style={styles.part}></View>
                    <View style={{ flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => { navigation.navigate('Profile', { petDetails: route?.params?.petDetails }) }}
                        >
                            <Image
                                source={{
                                    uri: petDetails.image_path,
                                }}
                                style={styles.profileImg}
                            />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={openModal}>
                            <View style={styles.input1}>
                                <Text style={{ fontFamily: 'Poppins-Regular', marginTop: 20, marginLeft: 5 }}>Write Something Here..</Text>
                            </View>

                        </TouchableOpacity>
                    </View>
                    <View style={styles.part}></View>
                    <View style={{ flexDirection: 'row' }}>
                        <View style={{ flexDirection: 'row', backgroundColor: '#e5e5e5', width: 110, height: 35, paddingTop: 5, padding: 5, borderRadius: 5 }}>
                            <Image
                                source={require('../Assets/addPhoto.png')}
                                style={{ width: 20, height: 20, marginTop: 3 }}
                            />
                            <Text style={{ marginTop: 4, marginLeft: 2, fontSize: 11, color: '#000' }}>Photo/Video</Text>
                        </View>
                        <View style={{ flexDirection: 'row', backgroundColor: '#e5e5e5', width: 95, height: 35, paddingTop: 5, padding: 5, borderRadius: 5, marginHorizontal: 4 }}>
                            <Image
                                source={require('../Assets/boy.png')}
                                style={{ width: 20, height: 20, marginTop: 3 }}
                            />
                            <Text style={{ marginTop: 4, marginLeft: 2, fontSize: 11, color: '#000' }}>Tag Friend</Text>
                        </View>
                        <View style={{ flexDirection: 'row', backgroundColor: '#e5e5e5', width: 110, height: 35, paddingTop: 5, padding: 5, borderRadius: 5 }}>
                            <Image
                                source={require('../Assets/smily.png')}
                                style={{ width: 20, height: 20, marginTop: 3 }}
                            />
                            <Text style={{ marginTop: 4, marginLeft: 5, fontSize: 11, color: '#000' }}>Feeling/Activity</Text>
                        </View>
                    </View>
                </View>

                <FlatList
                    // contentContainerStyle={{ paddingBottom: 200 }}
                    data={allPosts}

                    keyExtractor={item => item.id}
                    renderItem={({ item, index }) => (

                        <View style={{ backgroundColor: '#fff', padding: 10, width: '95%', alignSelf: 'center', marginTop: 10 }}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image
                                        source={{
                                            uri: item.pet_image,
                                        }}
                                        style={styles.profileImg1}
                                    />
                                    <View style={{ marginLeft: 10, marginTop: 10 }}>
                                        <Text style={{ fontSize: 15, color: 'gray' }}>{item?.pet_name} - {item?.cat_name}</Text>
                                        <Text style={{ fontSize: 12, color: 'gray' }}>{item?.location}</Text>

                                    </View>
                                </View>

                                <Icon name='dots-three-horizontal' size={20} color="gray" />
                            </View>
                            <Text style={styles.postText}>{item?.msg}</Text>
                            <View style={{ flexDirection: 'row' }}>
                                <Image
                                    source={{
                                        uri: item.post_img,
                                    }}
                                    style={styles.feedImg}
                                />

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <View style={{ flexDirection: 'row', marginTop: 2 }}>
                                        <TouchableOpacity onPress={() => likePost(item?.post_id)}>
                                            <Image
                                                source={require('../Assets/thumb.png')}
                                                style={{ width: 20, height: 20, marginTop: 3 }}
                                            />
                                        </TouchableOpacity>

                                        <Text style={{ marginTop: 4, marginLeft: 2, fontSize: 11, color: 'gray' }}>{item?.likes} Likes</Text>
                                    </View>
                                    <Text style={{ marginLeft: 10, fontSize: 12, marginTop: 5, color: 'gray' }}>{item?.total_comments} Comment</Text>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    <Icon1 name='sharealt' style={{ marginTop: 8 }} color="gray" />
                                    <Text style={{ fontSize: 12, marginLeft: 4, marginTop: 5, color: 'gray' }}>Share</Text>
                                </View>
                            </View>
                            <View style={styles.part}></View>
                            <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                                <Image
                                    source={require('../Assets/cat.jpg')}
                                    style={styles.commentImg}
                                />
                                <View style={{ marginLeft: 10, }}>
                                    <Text style={{ fontSize: 15, color: 'gray' }}>Hiii</Text>
                                    <Text style={{ fontSize: 12, color: 'gray' }}>Likes 0 Likes</Text>

                                </View>
                            </View>
                            <View >
                                <TextInput
                                    autoCompleteType="email"
                                    keyboardType="email-address"
                                    underlineColorAndroid="transparent"
                                    textContentType="emailAddress"
                                    placeholder="Write a Comment..."
                                    onChangeText={(text) => setEmail(text)}
                                    style={styles.input}
                                    placeholderTextColor={'gray'}
                                />
                            </View>
                        </View>
                    )}
                />


            </ScrollView>
            <Modal
                //  backdropColor={'transparent'}
                backdropOpacity={0.5}
                animationType="slide"
                transparent={true}
                visible={showPostModal}
                onRequestClose={() => {
                    setShowPostModal(false)

                }}
            >
                <View style={styles.modalWrapper2}>
                    <View style={styles.modalWrapp1}>
                        <View style={styles.content}>
                            <View style={{ backgroundColor: '#fff', padding: 10, width: '95%', alignSelf: 'center', marginTop: 10 }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <Text style={{ fontSize: 17, color: 'gray' }}>Create Post</Text>
                                    <TouchableOpacity onPress={() => setShowPostModal(false)}>
                                        <Icon name='cross' size={20} color="gray" />
                                    </TouchableOpacity>

                                </View>
                                <View style={styles.part}></View>
                                <View style={{ flexDirection: 'row' }}>
                                    <View
                                    >
                                        <Image
                                            source={{
                                                uri: petDetails.image_path,
                                            }}
                                            style={styles.profileImg}
                                        />
                                    </View>
                                    <View style={{marginTop:15}}>
                                        <TextInput
                                            autoCompleteType="email"
                                            keyboardType="email-address"
                                            underlineColorAndroid="transparent"
                                            textContentType="emailAddress"
                                            placeholder="Write Something Here..."
                                            onChangeText={(text) => setPostContent(text)}
                                            style={styles.input1}
                                            placeholderTextColor={'gray'}
                                        />
                                    </View>
                                </View>
                                <View style={styles.part}></View>
                                <View style={{ flexDirection: 'row' }}>
                                    <TouchableOpacity onPress={pickImageFromGallery}>
                                        <View style={{ flexDirection: 'row', backgroundColor: '#e5e5e5', width: 110, height: 35, paddingTop: 5, padding: 5, borderRadius: 5 }}>
                                            <Image
                                                source={require('../Assets/addPhoto.png')}
                                                style={{ width: 20, height: 20, marginTop: 3 }}
                                            />
                                            <Text style={{ marginTop: 4, marginLeft: 2, fontSize: 11, color: '#000' }}>Photo/Video</Text>
                                        </View>
                                    </TouchableOpacity>
                                    <View style={{ width: 95 }}>
                                    </View>
                                    <View style={{ width: 110, height: 35 }}>

                                    </View>
                                </View>
                                <TouchableOpacity style={styles.btn}>
                                    <Text style={styles.textStyle}>Post</Text>
                                </TouchableOpacity>
                            </View>
                        </View>

                    </View>
                </View>
            </Modal>
        </View>
    )
}

export default Posts

const styles = StyleSheet.create({
    profileImg: {
        width: 70,
        borderRadius: 80,
        height: 70,
        resizeMode: 'contain',
        // marginTop: 30,
        // alignSelf: 'center',
        marginLeft: 10,

    },
    profileImg1: {
        width: 60,
        borderRadius: 80,
        height: 60,
        // marginTop: 30,
        // alignSelf: 'center',
        marginLeft: 10,

    },
    commentImg: {
        width: 40,
        borderRadius: 80,
        height: 40,
        // marginTop: 30,
        // alignSelf: 'center',
        marginLeft: 10,
    },
    feedImg: {
        width: '100%',
        height: 220,
        // marginTop: 30,
        alignSelf: 'center',
        // marginLeft: 10,
        marginTop: 10,
        // resizeMode:'contain'

    },
    part: {
        borderWidth: 0.5,
        borderColor: 'lightgray',
        marginVertical: 15
    },
    input1: {
        // backgroundColor: '#fff',
        width: '100%',
        alignSelf: 'center',
        marginBottom: 10,
        borderRadius: 5,
        height: 40,
        // borderColor:'gray',
        // borderLeftColor:'gray'
    },
    input: {
        backgroundColor: '#fff',
        width: '100%',
        alignSelf: 'center',
        borderWidth: 0.5,
        marginBottom: 10,
        borderRadius: 5,
        height: 40,
        // borderColor:'gray',
        // borderLeftColor:'gray'
    },
    postText: { fontSize: 13, marginTop: 10, fontFamily: 'Poppins-Regular' },
    modalWrapp: {
        height: hp(48), width: wp(100), position: 'absolute',
        bottom: -10, backgroundColor: '#fff'
    },

    modalWrapp1: {
        height: hp(40), width: wp(95), position: 'absolute',
        bottom: 200, backgroundColor: '#fff',
        borderRadius: 20, elevation: 50
    },
    modalWrapper2: {
        flex: 1,
        // backgroundColor: "#00000040",
        alignItems: "center",
        justifyContent: "flex-end",

    },
    content: {
        alignSelf: 'center',
        marginTop: 10
    },
    textStyle: {
        color: '#fff',
        textAlign: 'center',
        fontFamily: 'Poppins-Regular'
    },
    btn: {
        backgroundColor: '#8AB645',
        borderRadius: 5,
        width: 80,
        // height:20,
        padding: 5,
        // elevation: 2,
        // width: wp(30),
        alignSelf: 'flex-end',
        marginTop: 10
    }
})