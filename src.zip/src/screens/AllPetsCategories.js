import { StyleSheet, Text, View, TouchableOpacity, FlatList, Image, Alert, PanResponder, Animated } from 'react-native'
import React, { useState, useEffect, useRef } from 'react';
import { AllPetsListingByCategory } from '../Redux/Actions/Petmeout';
import { useDispatch, useSelector } from 'react-redux';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { Globals } from '../Config/index';
import { Loader } from '../Component/Loader';
import LottieView from 'lottie-react-native';
import Modal from "react-native-modal";
import Icon from 'react-native-vector-icons/AntDesign';
import Slider from '@react-native-community/slider';
import AnimatedRangeSlider from '../Component/RangeSlider/AnimatedRangeSlider';

const AllPetsCategories = ({ route }) => {
    const navigation = useNavigation();
    const { ALLPETS_CATEGORY } = useSelector(state => state.PetmeOutReducer);
    console.log(ALLPETS_CATEGORY, 'jjjjjjjjjj')
    const [loader, setLoader] = useState(false);
    const dispatch = useDispatch();
    const [isModalVisible, setModalVisible] = useState(false);

    const toggleModal = () => {
        setModalVisible(!isModalVisible);
    };
    useEffect(() => {
        setLoader(true);
        dispatch(AllPetsListingByCategory(route?.params?.categoryName));
        setTimeout(() => {
            setLoader(false);
        }, 2000);
    }, []);
    const thumbImage = require('../Assets/images/pawBG.jpg'); // Update with your image path

    return (

        <View style={{ backgroundColor: ALLPETS_CATEGORY == null ? '#fff' : 'transparent', flex: 1 }}>
            <Loader flag={loader} />
            {
                ALLPETS_CATEGORY == null ?
                    <View style={{ marginTop: 150, backgroundColor: '#fff' }}>

                        <LottieView
                            source={require("../Assets/lottie/notFound.json")}
                            style={{
                                width: 200,
                                height: 200,
                                alignSelf: 'center',
                            }}
                            autoPlay loop
                        />


                    </View>
                    :
                    <>
                        <View style={{ flexDirection: 'row', alignSelf: 'center', justifyContent: 'space-between', width: '90%' }}>
                            <Text style={{ textAlign: 'center', fontSize: 20, fontFamily: 'Poppins-SemiBold', marginTop: 10, color: '#000', marginLeft: 20 }}>All Pets of {route?.params?.categoryName} Category</Text>
                            <TouchableOpacity onPress={toggleModal}>
                                <LottieView
                                    source={require("../Assets/lottie/sort.json")}
                                    style={{
                                        width: 50,
                                        height: 50,
                                        alignSelf: 'center',

                                    }}
                                    autoPlay loop
                                />
                            </TouchableOpacity>
                        </View>

                        <View style={{ alignSelf: 'center', borderRadius: 10, width: '100%' }}>


                            <FlatList
                                // contentContainerStyle={{ paddingBottom: 200 }}
                                data={ALLPETS_CATEGORY}
                                contentContainerStyle={{
                                    alignSelf: 'center',
                                    alignItems: 'center',
                                    paddingBottom: 100
                                }}
                                showsVerticalScrollIndicator={false}
                                columnWrapperStyle={{ flexWrap: 'wrap' }}
                                // numColumns={2}j
                                numColumns={3}
                                keyExtractor={(item, index) => index}
                                renderItem={({ item, index }) => (
                                    <TouchableOpacity
                                        onPress={() => { navigation.navigate('Profile', { petDetails: item }) }}
                                        style={{ marginTop: 10 }}>
                                        {
                                            item?.image_path.includes('admin') ?
                                                <Image
                                                    source={{
                                                        uri: item?.image_path,
                                                    }}
                                                    style={{
                                                        height: 100, width: 100, marginLeft: 10, borderRadius: 10
                                                    }}
                                                    resizeMode='contain'
                                                />
                                                :
                                                <Image
                                                    source={require('../Assets/none.jpg')}
                                                    style={{
                                                        height: 100, width: 100, marginLeft: 10, borderRadius: 10
                                                    }}
                                                    resizeMode='contain'
                                                />



                                        }

                                        <Text
                                            style={{
                                                color: '#8b9088',
                                                fontSize: 15,
                                                textAlign: 'center',
                                                marginTop: 7,
                                                fontFamily: 'Poppins-Regular'
                                            }}>
                                            {item?.pet_name}
                                        </Text>
                                    </TouchableOpacity>

                                )}
                            />


                        </View>
                    </>
            }
            <Modal isVisible={isModalVisible} style={styles.modal} animationOutTiming={700} backdropTransitionOutTiming={800}>
                <View style={styles.modalContent}>
                    <Text style={{ fontFamily: 'Poppins-Bold', fontSize: 16, color: '#000' }}>Sort by Distance:</Text>

                    <TouchableOpacity title="Hide modal" onPress={toggleModal} style={{ position: 'absolute', right: 10, top: 20 }} >
                        <Icon size={20} name='close' color='#000' />
                    </TouchableOpacity>
                    <LottieView
                        source={require("../Assets/lottie/truck.json")}
                        style={{
                            width: 100,
                            height: 80,
                            alignSelf: 'center',

                        }}
                        autoPlay loop
                    />
                    <AnimatedRangeSlider
                        min={0}
                        max={100}
                        initialMin={20}
                        initialMax={80}
                        thumbImage={thumbImage}

                    />
                    <TouchableOpacity style={[styles.btn, { height: 37, backgroundColor: '#fbd349', borderRadius: 20, marginTop: 10 ,width:'50%',alignSelf:'center',marginTop:10}]}>
                        <Text style={{ color: '#000', fontSize: 13, fontFamily: 'Poppins-Regular', marginTop: 10, textAlign: 'center' }}>Done</Text>

                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    )
}

export default AllPetsCategories

const styles = StyleSheet.create({
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    modalContent: {
        height: 300, // Fixed height for the modal content
        backgroundColor: 'white',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        padding: 20,
    },

    slider: {
        width: '100%',
        height: 80,
    },
    rail: {
        flex: 1,
        height: 10,
        borderRadius: 5,
        backgroundColor: '#ddd',
    },
    railSelected: {
        height: 10,
        backgroundColor: '#007bff',
        borderRadius: 5,
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: 'red',
    },
    label: {
        color: '#333',
        marginTop: 20,
    },
    valueLabel: {
        textAlign: 'center',
        marginBottom: 10,
        fontSize: 16,
    },
    root: {
        width: 8,
        height: 8,
        borderLeftColor: 'blue',
        borderRightColor: 'blue',
        borderBottomColor: 'transparent',
        borderLeftWidth: 4,
        borderRightWidth: 4,
        borderBottomWidth: 8,
    },

    Rootcontainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    slider: {
        height: 40,
        justifyContent: 'center',
    },
    track: {
        height: 4,
        backgroundColor: '#ddd',
        position: 'absolute',
        left: 0,
        right: 0,
    },
    selectedTrack: {
        height: 4,
        backgroundColor: 'blue',
        position: 'absolute',
    },
    thumb: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: 'blue',
        position: 'absolute',
        top: -8,
    },
    valuesContainer: {
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: 300,
    },
})